const itemInCart = [
    {
        id: 1,
        productID: 1,
        productName: "Apple",
        unitID: 1,
        unit: 1,
        pricePerUnit: 2.99,
    },

    {
        id: 2,
        productID: 2,
        productName: "Orange",
        unitID: 1,
        unit: 1.50,
        pricePerUnit: 1.99,
    }
];

export default itemInCart;
