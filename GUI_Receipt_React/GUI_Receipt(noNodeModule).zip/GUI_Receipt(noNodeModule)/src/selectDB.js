import mysql from "mysql2"; 

var connection = mysql.createConnection(
    {
        host: "localhost",
        user: "root",
        password: "P8gn8pech$",
        database: "smartcart"
    }
);

connection.connect(function (err) {
    if (err) throw err;
    connection.query("SELECT * FROM productinfo", function (err, result, fields) {
        if (err) throw err;
        console.log(result);
    });
});