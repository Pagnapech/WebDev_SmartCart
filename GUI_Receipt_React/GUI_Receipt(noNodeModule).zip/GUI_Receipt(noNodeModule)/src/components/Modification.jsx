import React from "react"; 

function insertIntoTable(data) {
    return (
        <Table 
            key={data.id}
            productID={data.productID}
            productName={data.productName}
            unitID={data.unitID}
            unit={data.unit}
            pricePerUnit={data.pricePerUnit}
        />
    );
};

function Table(props) {
    return (
        <tr>
            <td>{props.productID}</td>
            <td>{props.productName}</td>
            <td>{props.unitID}</td>
            <td>{props.unit}</td>
            <td>{props.pricePerUnit}</td>
            <td>{(props.unit * props.pricePerUnit).toFixed(2)}</td> 
        </tr>

    );

}

export default insertIntoTable; 