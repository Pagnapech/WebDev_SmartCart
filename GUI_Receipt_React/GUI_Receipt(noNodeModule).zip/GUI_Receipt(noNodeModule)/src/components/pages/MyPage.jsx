import React, { useState } from "react"; 
import { BrowserRouter, Routes, Route } from "react-router-dom";
import GUI from "./GUI.jsx"; 
import Prompt from "./Prompt.jsx"; 
import Receipt from "./Receipt.jsx"; 

function MyPage() {
    return (
        <BrowserRouter>
            <Routes>
                <Route exact path="/" element={<GUI />} />
                <Route path="/prompt" element={<Prompt />} />
                <Route path="/prompt/receipt" element={<Receipt />} />
            </Routes>
        </BrowserRouter>
    ); 
}

export default MyPage; 