import React from "react";
import itemInCart from "../../itemInTable.js";
import insertIntoTable from "../Modification.jsx";
import { Link } from "react-router-dom"; 
 
//TO DO LIST for GUI 
/* 
    Useful for Sign-In, Sign-Up , ... 
        link: https://www.youtube.com/watch?v=wOxP4k9f5rk&list=PLl81VCtqC3vzye_aB-IkhGI940tHUH20o&index=9&t=100s


    1. Design the GUI Page 
    2. Build the functionality of the Table and Button
    3. Link the Button to the Receipt Page 
        link: https://www.w3schools.com/react/react_router.asp
    4. Retrieve the Data from Database (mySQL) and insert to the Table by inserting to itemInTable.js
    // Create a Containerization of Table in mySQL for specific customer during shopping 
    // Use node.js to retrieve the data from that table 
    // link: https://www.w3schools.com/nodejs/nodejs_mysql_insert.asp 
    5. Figure out the Python Script from Object Detection and retrieve data from mySQL
        (Insert or Remove from the Cart Table) 
        link: https://www.w3schools.com/python/python_mysql_select.asp 
    6. Create a Containerization of the Data for the Table from Object Detection
    After Done Shopping: 
    7. Insert necessary data to the Database: 
        - Order ID
        - Customer Info (create arbitrary first, require data from Sign In)
        - Purchase Date
        - Total 
    8. Store important data for Receipt Page 
        - Order ID
        - Customer ID
        - Customer First Name
        - Purchase Date 
        - Total 
*/

function GUI() {

    // function changePage() {
    //     return <a href=""> </a>
    // }

    return (
        <div> 
            <h1>GUI Cart</h1>
            {/* This table aligns to the center */}
            {/* Create a dynamic Table in React */}
            <table>
                <tr>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Unit ID</th>
                    <th>Unit</th>
                    <th>Price Per Unit</th>
                    <th>Subtotal</th>
                </tr>

                {/* {itemInCart.map( (value, key) => {
                    return (
                        <tr id={key}>
                            <td>{value.productID}</td>
                            <td>{value.productName}</td>
                            <td>{value.unitID}</td>
                            <td>{value.unit}</td>
                            <td>{value.pricePerUnit}</td>
                            <td>{(value.unit * value.pricePerUnit).toFixed(2)}</td> 
                        </tr>
                    )
                })} */}

                {itemInCart.map(insertIntoTable)} 

            </table>

            <p>Total: <span>$ Add all subtotal</span></p>
            <Link to="/prompt"><button> DONE SHOPPING</button></Link>

        </div>
    );
}

export default GUI; 


//Resources Link: https://www.geeksforgeeks.org/how-to-create-a-table-in-reactjs/