import React from "react"; 
import { Link } from "react-router-dom";
//TO DO LIST for Receipt 
/* 
    1. Design the Receipt Page 
    2. Build the functionality of the Table
    3. Retrieve the Data from the GUI Containerization
    4. Print out the Data from GUI Containerization:
        - Order ID
        - Customer ID
        - Customer First Name
        - Purchase Date 
        - Total 
*/

function Receipt() { 
    return (
        <div>
            {/* Align to the center of the page */}
            <h1>Receipt</h1>  
            <h2>Store Name</h2>
            <h2>Store Address</h2>
            
            {/* These ID and name are align to the left */}
            <p>Order ID: <span>id in the box</span></p>
            <p>Customer ID: <span>id in the box</span></p>
            <p>Customer First Name: <span>name in the box</span></p>
            {/* This table is align at the left  */}
            <table>
                <tr>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Unit ID</th> 
                    <th>Unit</th>
                    <th>Price Per Unit</th>
                    <th>Subtotal</th>
                </tr>    

            </table>

            {/* Purchase Date aligns to the left */}
            <p>Purchase Date: <span>Current date and time in the box</span></p>
            {/* Total aligns to the right */}
            <p>Total: <span>total price in the box</span></p>
            <Link to="/"><button>Return To Home</button></Link>
        </div>
        
        
    );
}


export default Receipt; 
