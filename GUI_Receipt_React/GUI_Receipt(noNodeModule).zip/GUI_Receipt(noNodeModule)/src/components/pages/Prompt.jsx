import React from "react"; 
import { Link } from "react-router-dom";


function Prompt() {
    return (
        <div>
            <p>Are you done Shopping?</p>
            <Link to="/prompt/receipt"><button>Yes</button></Link>
            <Link to="/"><button>No</button></Link>
        </div>
    );
    
}
        
    
export default Prompt ;

