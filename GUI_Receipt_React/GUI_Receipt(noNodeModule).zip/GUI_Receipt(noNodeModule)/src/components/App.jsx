import React from "react"; 
import MyPage from "./pages/MyPage.jsx"; 

function App() {
  return ( 
      <MyPage /> 
  );
}


export default App;

//Resources: https://uci.udemy.com/course-dashboard-redirect/?course_id=1565838
